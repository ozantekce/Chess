package Frameworks;


public enum ID {
    
    Pawn(), Bishop(), King(), Knight(), Queen(), Rook() ;
    
    
}
